using UnityEngine;
public class PlayerController : MonoBehaviour
{
    public float speed = 5f;
    public float jumpForce = 7f;
    public float crouchSpeed = 2.5f; // Velocidad reducida al agacharse
    private bool isGrounded = false;
    private bool canDoubleJump = false; // Permitir doble salto
    private Rigidbody2D rb;
    private Animator anim;
    
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    void Update()
    {
        // Movimiento horizontal
        float moveInput = Input.GetAxis("Horizontal");

        // Comprobar si el jugador está agachado
        if (Input.GetKey(KeyCode.S)) // Cambiado a la tecla S
        {
            rb.linearVelocity = new Vector2(moveInput * crouchSpeed, rb.linearVelocity.y);
            anim.SetBool("isCrouching", true); // Activar animación de agachado
        }
        else
        {
            rb.linearVelocity = new Vector2(moveInput * speed, rb.linearVelocity.y);
            anim.SetBool("isCrouching", false);
        }

        // Cambiar animación de movimiento
        anim.SetBool("isMoving", moveInput != 0);

        // Saltar
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (isGrounded)
            {
                rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
                anim.SetBool("isJumping", true);
                canDoubleJump = true; // Permitir el segundo salto
            }
            else if (canDoubleJump)
            {
                rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
                anim.SetTrigger("DoubleJump"); // Activar animación de doble salto
                canDoubleJump = false; // No se puede saltar más después del doble salto
            }
        }

        // Ataque en el suelo
        if (Input.GetMouseButtonDown(0) && isGrounded) // Clic izquierdo para atacar
        {
            anim.SetTrigger("Attack");
        }

        // Ataque en el aire (cuando no está en el suelo)
        if (Input.GetMouseButtonDown(0) && !isGrounded)
        {
            anim.SetTrigger("AirAttack"); // Activar animación de ataque aéreo
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            isGrounded = true;
            anim.SetBool("isJumping", false); // Volver a estado normal al tocar el suelo
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            isGrounded = false;
        }
    }
}
